-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2023 at 01:29 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wildswimming`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `AdminID` int(11) NOT NULL,
  `AdminName` varchar(30) DEFAULT NULL,
  `AdminPhNo` varchar(30) DEFAULT NULL,
  `AdminEmail` varchar(30) DEFAULT NULL,
  `AdminPassword` varchar(30) DEFAULT NULL,
  `AdminAddress` varchar(220) DEFAULT NULL,
  `AdminPosition` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`AdminID`, `AdminName`, `AdminPhNo`, `AdminEmail`, `AdminPassword`, `AdminAddress`, `AdminPosition`) VALUES
(1, 'Jay', '+959444333222', 'jayjo2323@gmail.com', '111111111', 'Pyong Yang', 'Manager'),
(2, 'Shelly', '+959223332111', 'shellyx89@gmail.com', '123456789', 'Seoul', 'Supervisor'),
(4, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `BookingID` int(11) NOT NULL,
  `BookingDate` date DEFAULT NULL,
  `PitchID` int(11) DEFAULT NULL,
  `BookingStatus` varchar(50) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Subtotal` int(11) DEFAULT NULL,
  `Tax` int(11) DEFAULT NULL,
  `CustomerEmail` varchar(50) DEFAULT NULL,
  `BookingQty` int(11) DEFAULT NULL,
  `PaymentType` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`BookingID`, `BookingDate`, `PitchID`, `BookingStatus`, `Price`, `Subtotal`, `Tax`, `CustomerEmail`, `BookingQty`, `PaymentType`) VALUES
(1, '0000-00-00', 2, 'Active', 0, 0, 0, 'Matty23@gmail.com', 5, 'Cash'),
(2, '2023-09-29', 2, 'Active', 0, 0, 0, 'Matty23@gmail.com', 4, 'Cash'),
(3, '2023-09-29', 2, 'Active', 3000, 3300, 300, 'Matty23@gmail.com', 5, 'Visa'),
(4, '2023-09-30', 2, 'Active', 3000, 26400, 300, 'wiwi777guyy@gmail.com', 8, 'Cash'),
(5, '2023-09-30', 2, 'Active', 3000, 26400, 300, 'wiwi777guyy@gmail.com', 8, 'Cash'),
(6, '2023-09-28', 1, 'Active', 280, 924, 28, 'wiwi777guyy@gmail.com', 3, 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `campsite`
--

CREATE TABLE `campsite` (
  `CampsiteID` int(11) NOT NULL,
  `CampsiteName` varchar(30) DEFAULT NULL,
  `CampstieLocation` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `campsite`
--

INSERT INTO `campsite` (`CampsiteID`, `CampsiteName`, `CampstieLocation`) VALUES
(1, 'Chicago Camp Site', 'Chicago City'),
(2, 'New York Campsite', 'New York'),
(3, 'UK Campsite', 'United Kingdom'),
(4, 'Asia Campsite', 'Asia');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ContactID` int(11) NOT NULL,
  `ContactMessage` varchar(200) DEFAULT NULL,
  `PhNo` varchar(30) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ContactID`, `ContactMessage`, `PhNo`, `Email`) VALUES
(1, 'Keep on goin', '09756296368', 'wiwi777guyy@gmail.com'),
(2, 'kk;', '09756296368', 'wiwi777guyy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerId` int(11) NOT NULL,
  `CustomerFirstName` varchar(30) DEFAULT NULL,
  `CustomerSurname` varchar(30) DEFAULT NULL,
  `CustomerEmail` varchar(30) DEFAULT NULL,
  `CustomerPh` varchar(30) DEFAULT NULL,
  `CustomerPassword` varchar(30) DEFAULT NULL,
  `CustomerAddress` varchar(220) DEFAULT NULL,
  `Viewcount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerId`, `CustomerFirstName`, `CustomerSurname`, `CustomerEmail`, `CustomerPh`, `CustomerPassword`, `CustomerAddress`, `Viewcount`) VALUES
(1, 'Matty', 'Healy', 'matty23@gmail.com', '+959643326868', 'youknowthesound', 'New York', 36),
(2, 'ab', 'cd', 'abcd123@gmail.com', '+959643326868', '12345678', 'mm', 15),
(3, 'Ben', 'Affleck', 'benaff2023@gmail.com', '+959643326868', '111111111', 'Florida', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pitch`
--

CREATE TABLE `pitch` (
  `PitchID` int(11) NOT NULL,
  `PitchName` varchar(50) DEFAULT NULL,
  `PitchImage` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `FNm1` varchar(50) DEFAULT NULL,
  `FNm2` varchar(50) DEFAULT NULL,
  `FNm3` varchar(50) DEFAULT NULL,
  `FImg1` varchar(255) DEFAULT NULL,
  `FImg2` varchar(255) DEFAULT NULL,
  `FImg3` varchar(255) DEFAULT NULL,
  `FDes1` varchar(255) DEFAULT NULL,
  `FDes2` varchar(255) DEFAULT NULL,
  `FDes3` varchar(255) DEFAULT NULL,
  `LANm1` varchar(50) DEFAULT NULL,
  `LANm2` varchar(50) DEFAULT NULL,
  `LANm3` varchar(50) DEFAULT NULL,
  `LAImg1` varchar(255) DEFAULT NULL,
  `LAImg2` varchar(255) DEFAULT NULL,
  `LAImg3` varchar(255) DEFAULT NULL,
  `LDes1` varchar(255) DEFAULT NULL,
  `LDes2` varchar(255) DEFAULT NULL,
  `LDes3` varchar(255) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `CampsiteID` int(11) DEFAULT NULL,
  `PitchTypeID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pitch`
--

INSERT INTO `pitch` (`PitchID`, `PitchName`, `PitchImage`, `location`, `FNm1`, `FNm2`, `FNm3`, `FImg1`, `FImg2`, `FImg3`, `FDes1`, `FDes2`, `FDes3`, `LANm1`, `LANm2`, `LANm3`, `LAImg1`, `LAImg2`, `LAImg3`, `LDes1`, `LDes2`, `LDes3`, `Price`, `Description`, `Status`, `CampsiteID`, `PitchTypeID`) VALUES
(1, 'Greenwood Pitch', 'dash01.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d750.4702179901238!2d0.20928990487482238!3d50.93168126193757!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47df68cea32710db%3A0x15e0a07f209bed1e!2sDernwood%20Farm%20Wild%20Camping!5e0!3m2!1sen!2sm', 'Tents', 'Picnic tables', 'Pet-friendly areas', 'row1.jpg', 'picnic_table.jpg', 'patfriendlyarea.jpg', 'Tents serve as portable shleters', 'Picnic tables are for various uses.', 'For your pets', 'Statue of LIbery', 'Tokyo tower', 'The Great Wall', 'is3.jpg', 'is5.jpg', 'is6.jpg', 'Liberty statue locates in New York. ', 'Tokyo tower is in Tokyo.', 'The Great wall is in China.', 280, 'This camping pitch can provide you a lot of natural experiences.', 'Active', 1, 3),
(2, 'Ottawa Pitch', '', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2793.2674489460965!2d-75.77128162048793!3d45.565060062790835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cce1e171594c381%3A0xe9875d30bb24897f!2sCamping%20Cantley!5e0!3m2!1sen!2smm!4v1694318029', 'WIfi', 'Pet-friendly Area', 'Potable Water', 'wifi.jpg', 'patfriendlyarea.jpg', 'potablewater.jpg', ' While camping is often an opportunity to disconnect, some campgrounds provide Wi-Fi.', 'For your pets', 'Access to clean drinking water is essential', 'Liberty', 'Tokyo Tower', 'Great Wall', 'is3.jpg', 'is5.jpg', 'is6.jpg', 'Liberty statue locates in New York. ', 'Tokyo tower is in Tokyo.', 'The Great wall is in China.', 3000, 'This is a pitch in canada which will provid a lot of camping experiences', 'Active', 1, 3),
(3, 'Lake District National Park', '', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1159.562025610788!2d-3.0896875580223915!3d54.460747006901265!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487cc16220357017%3A0x17b57bddea6a7a86!2sLake%20District%20National%20Park!5e0!3m2!1sen!2', 'Tents', 'Wifi', 'Picnic Tables', 'row1.jpg', 'wifi.jpg', 'picnic_table.jpg', 'Tents serve as portable shelters primarily used for outdoor activities.', 'For your connection', 'Picnic Tables Are For Various Uses.', 'Lake Windermere', 'Honister Slate Mine', 'Keswick', 'lakewinder.jpg', 'honister.jpg', 'keswick.jpg', 'The largest natural lake in England, Lake Windermere is a must-visit.', ': Take a tour of this working slate mine to learn about the history of slate mining in the Lake District', 'This charming town serves as a hub for exploring the northern Lake District.', 2000, 'his national park offers numerous camping options, including Great Langdale Campsite, Keswick Camping and Caravanning Club Site, and more.', 'Active', 3, 6),
(4, 'Naguri Lake Campground', 'Naguri.jpg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12930.70076145042!2d139.1377576985538!3d35.881475896159216!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6019317d1372d861%3A0x3e190c7b50c9c475!2sNaguri%20Lake!5e0!3m2!1sen!2smm!4v1696234749940!5m', 'Tents', 'Wifi', 'Picnic Tables', 'row1.jpg', 'wifi.jpg', 'picnic_table.jpg', 'Tents serve as portable shleters.', 'For your connection', 'Picnic tables are for various uses', 'Naguri Lake Park', 'Tokyo Tower', 'Okutama Hot Springs', 'is2.jpg', 'is5.jpg', 'hotspring.jpg', 'This park area near the lake has a playground for children and offers a pleasant place for a leisurely stroll.', 'Tokyo tower is in Tokyo.', ' While not directly at Naguri Lake, there are hot spring resorts in the Okutama area. After a day of outdoor activities, you can relax in one of these onsens (hot spring baths).', 2300, ' Located in Chichibu, Saitama Prefecture, which is accessible from Tokyo by train, this campground offers scenic lakeside camping and outdoor activities.', 'Active', 4, 9);

-- --------------------------------------------------------

--
-- Table structure for table `pitchtype`
--

CREATE TABLE `pitchtype` (
  `PitchTypeID` int(11) NOT NULL,
  `PitchTypeName` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pitchtype`
--

INSERT INTO `pitchtype` (`PitchTypeID`, `PitchTypeName`) VALUES
(3, 'Caramel Pitch '),
(6, 'Touring Caravan '),
(9, 'Motorhome');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ReviewID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `ReviewMessage` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ReviewID`, `CustomerID`, `Rating`, `ReviewMessage`) VALUES
(1, 1, 4, 'msg'),
(2, 1, 5, 'msg'),
(3, 1, 4, 'Goooooooooood'),
(4, 2, 5, 'Excellent Sevice and facilities');

-- --------------------------------------------------------

--
-- Table structure for table `tblrss`
--

CREATE TABLE `tblrss` (
  `RSSFeedID` int(11) NOT NULL,
  `Title` varchar(30) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblrss`
--

INSERT INTO `tblrss` (`RSSFeedID`, `Title`, `Description`, `URL`) VALUES
(1, 'Home Page', 'This is the page to show the contents of pitch, facilities of GWCS', 'http://localhost/Global_Wild_Swimming/Home_Page.php'),
(2, 'Information', 'This page is to show the information of pitches.', 'http://localhost/Global_Wild_Swimming/Information.php'),
(3, 'Pitch Type and Availability', 'This page is to check the availability of pitches. Users can also search for the pitches by name.', 'http://localhost/Global_Wild_Swimming/PtNA.php'),
(4, 'Reviews', 'This page is for the users to give review for the website.', 'http://localhost/Global_Wild_Swimming/Review.php'),
(5, 'Contact us', 'This page is for users to contact to the GWCS.', 'http://localhost/Global_Wild_Swimming/Contact.php');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingID`),
  ADD KEY `PitchID` (`PitchID`);

--
-- Indexes for table `campsite`
--
ALTER TABLE `campsite`
  ADD PRIMARY KEY (`CampsiteID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ContactID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerId`);

--
-- Indexes for table `pitch`
--
ALTER TABLE `pitch`
  ADD PRIMARY KEY (`PitchID`),
  ADD KEY `CampsiteID` (`CampsiteID`),
  ADD KEY `PitchTypeID` (`PitchTypeID`);

--
-- Indexes for table `pitchtype`
--
ALTER TABLE `pitchtype`
  ADD PRIMARY KEY (`PitchTypeID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `CustomerID` (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `campsite`
--
ALTER TABLE `campsite`
  MODIFY `CampsiteID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ContactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pitch`
--
ALTER TABLE `pitch`
  MODIFY `PitchID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pitchtype`
--
ALTER TABLE `pitchtype`
  MODIFY `PitchTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ReviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`PitchID`) REFERENCES `pitch` (`PitchID`);

--
-- Constraints for table `pitch`
--
ALTER TABLE `pitch`
  ADD CONSTRAINT `pitch_ibfk_1` FOREIGN KEY (`CampsiteID`) REFERENCES `campsite` (`CampsiteID`),
  ADD CONSTRAINT `pitch_ibfk_2` FOREIGN KEY (`PitchTypeID`) REFERENCES `pitchtype` (`PitchTypeID`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
